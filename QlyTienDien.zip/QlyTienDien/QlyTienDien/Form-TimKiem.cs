﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace QlyTienDien
{
    public partial class Form_TimKiem : Form
    {
        CSDL qly = new CSDL();

        public Form_TimKiem()
        {
            InitializeComponent();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            // Kiểm tra
            if (rdbKH.Checked == true)
            {
                // Tìm theo kh
                dgvTim.DataSource = qly.timKiem(false, txtInfo.Text);
            }
            else
            {
                // Tìm theo dh
                dgvTim.DataSource = qly.timKiem(true, txtInfo.Text);
            }
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            txtInfo.Text = "";
            txtInfo.Focus();
        }

        private void btnOut_Click(object sender, EventArgs e)
        {
            Dispose();
        }
    }
}
