﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace QlyTienDien
{
    public partial class Form_NhapHoaDon : Form
    {
        CSDL qly = new CSDL();
        int type; // 1: them, 2 sua

        public Form_NhapHoaDon()
        {
            InitializeComponent();
        }

        private void Form_NhapHoaDon_Load(object sender, EventArgs e)
        {
            // Lấy toàn bộ hóa đơn lên
            dgvHD.DataSource = qly.getAllHD();

            // Lấy toàn bộ kh lên cbo
            cboKH.DataSource = qly.getAllKH();
            cboKH.DisplayMember = "tenkh";
            cboKH.ValueMember = "makh";
        }

        private void dgvHD_Click(object sender, EventArgs e)
        {
            if (dgvHD.SelectedRows.Count > 0)
            {
                // Lấy thông tin row đang chọn lên field
                DataGridViewRow nowRow = dgvHD.SelectedRows[0];

                // Set lên các field
                txtMaHD.Text = nowRow.Cells[0].Value.ToString();
                txtOld.Text = nowRow.Cells[2].Value.ToString();
                txtNew.Text = nowRow.Cells[3].Value.ToString();
                txtKW.Text = nowRow.Cells[4].Value.ToString();
                txtTotal.Text = nowRow.Cells[5].Value.ToString();
                cboKH.SelectedValue = nowRow.Cells[1].Value;
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            // Clear toàn bộ txt
            txtTotal.Text = txtOld.Text = txtNew.Text = txtMaHD.Text = txtKW.Text = "";

            // Set disabled các nút
            btnAdd.Enabled = btnDel.Enabled = btnEdit.Enabled = false;

            // Set enabled các nút
            btnSave.Enabled = btnCancel.Enabled = true;

            // Set type
            type = 1; // 1 => thêm
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            // Kiểm tra nếu đã chọn column
            if (dgvHD.SelectedRows.Count > 0)
            {
                // Set disabled các nút
                btnAdd.Enabled = btnDel.Enabled = btnEdit.Enabled = false;

                // Set enabled các nút
                btnSave.Enabled = btnCancel.Enabled = true;

                // Set type
                type = 2; // 1 => thêm
            }
            else
            {
                MessageBox.Show("Xin hãy chọn dòng để sửa!");
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            // Set enabled các nút
            btnAdd.Enabled = btnDel.Enabled = btnEdit.Enabled = true;

            // Set disabled các nút
            btnSave.Enabled = btnCancel.Enabled = false;
        }

        private void btnOut_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            // Kiểm tra nếu nhập đủ 
            if (txtMaHD.Text != "" && txtOld.Text != "" && txtNew.Text != "")
            {
                // Nếu thêm
                if (type == 1)
                {
                    // Lấy thông tin
                    int socu = Convert.ToInt16(txtOld.Text);
                    int somoi = Convert.ToInt16(txtNew.Text);
                    int kw = Convert.ToInt16(txtKW.Text);
                    int tien = Convert.ToInt32(txtTotal.Text);

                    // Thêm và kiểm tra
                    if (qly.themHoaDon(txtMaHD.Text, cboKH.SelectedValue.ToString(), socu, somoi, kw, tien))
                    {
                        MessageBox.Show("Đã thêm thành công");

                        // Show lại
                        dgvHD.DataSource = qly.getAllHD();

                        // Set enabled các nút
                        btnAdd.Enabled = btnDel.Enabled = btnEdit.Enabled = true;

                        // Set disabled các nút
                        btnSave.Enabled = btnCancel.Enabled = false;
                    }
                    else
                    {
                        MessageBox.Show("Thêm thất bại");
                    }
                }
                else
                {
                    // Sửa, kiểm tra nếu ID có bị thay đổi
                    if (txtMaHD.Text == dgvHD.SelectedRows[0].Cells[0].Value.ToString())
                    {
                        // Lấy thông tin
                        int socu = Convert.ToInt16(txtOld.Text);
                        int somoi = Convert.ToInt16(txtNew.Text);
                        int kw = Convert.ToInt16(txtKW.Text);
                        int tien = Convert.ToInt32(txtTotal.Text);

                        // Thêm và kiểm tra
                        if (qly.suaHoaDon(txtMaHD.Text, cboKH.SelectedValue.ToString(), socu, somoi, kw, tien))
                        {
                            MessageBox.Show("Đã sửa thành công");

                            // Show lại
                            dgvHD.DataSource = qly.getAllHD();

                            // Set enabled các nút
                            btnAdd.Enabled = btnDel.Enabled = btnEdit.Enabled = true;

                            // Set disabled các nút
                            btnSave.Enabled = btnCancel.Enabled = false;
                        }
                        else
                        {
                            MessageBox.Show("Sửa thất bại");
                        }
                    }
                    else
                    {
                        MessageBox.Show("Không thể sửa ID của hóa đơn khi sửa!");
                    }
                }
            }
            else
            {
                MessageBox.Show("Xin hãy nhập đầy đủ thông tin!");
            }
        }

        private void btnDel_Click(object sender, EventArgs e)
        {
            // Kiểm tra nếu đã chọn row
            if (dgvHD.SelectedRows.Count > 0)
            {
                // Hỏi ng` dùng
                if (MessageBox.Show("Bạn muốn xóa?", "Xóa", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
                {
                    // Có xóa
                    string id = dgvHD.SelectedRows[0].Cells[0].Value.ToString();

                    // Xóa và kiểm tra
                    if (qly.xoaHoaDon(id))
                    {
                        MessageBox.Show("Xóa thành công");

                        // Show lại
                        dgvHD.DataSource = qly.getAllHD();
                    }
                    else
                    {
                        MessageBox.Show("Xóa thất bại");
                    }
                }
            }
            else
            {
                MessageBox.Show("Hãy chọn dòng để xóa");
            }
        }

        private void txtOld_Validating(object sender, CancelEventArgs e)
        {
            try
            {
                Convert.ToInt32(txtOld.Text);
            }
            catch
            {
                MessageBox.Show("Số cũ phải là số nguyên!");
                txtOld.Text = "";
                txtOld.Focus();
            }
        }

        private void txtNew_Validating(object sender, CancelEventArgs e)
        {
            // Nếu số cũ chưa nhập
            if (txtOld.Text == "")
            {
                MessageBox.Show("Hãy nhập số cũ trước");
                txtNew.Text = "";
                txtOld.Focus();
            }
            else
            {
                try
                {
                    Convert.ToInt32(txtNew.Text);
                }
                catch
                {
                    MessageBox.Show("Số mới phải là số nguyên!");
                    txtNew.Text = "";
                    txtNew.Focus();
                }
            }
        }

        private void txtNew_Leave(object sender, EventArgs e)
        {
            if (txtOld.Text != "" && txtNew.Text != "")
            {
                // TÍnh tiền
                int socu = Convert.ToInt16(txtOld.Text);
                int somoi = Convert.ToInt16(txtNew.Text);

                // Kiểm tra nếu số cũ > số mới
                if (socu > somoi)
                {
                    MessageBox.Show("Số cũ ko thế lớn hơn số mới, xin hãy nhập lại số mới");

                    // Set "" và focus cái số mới
                    txtNew.Text = "";
                    txtNew.Focus();
                }
                else
                {
                    int kw = somoi - socu;
                    int tien = 0;

                    // Nếu chưa xài quá 50
                    if (kw < 50)
                    {
                        tien = kw * 3000;
                    }
                    else
                    {
                        // Xài quá 50, 50 * 3000, còn số quá * 3500
                        tien = 50 * 3000;
                        tien += (kw - 50) * 3500;
                    }

                    // Set lên txt
                    txtKW.Text = kw.ToString();
                    txtTotal.Text = tien.ToString();
                }
            }
        }
    }
}
