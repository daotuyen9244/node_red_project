﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace QlyTienDien
{
    public class CSDL
    {
        // Khai báo connection
        SqlConnection _conn = new SqlConnection("Data Source=.\\SQLEXPRESS;Initial Catalog=QlyTienDien;Integrated Security=True");

        /// <summary>
        /// Hàm lấy toàn bộ hóa đơn
        /// </summary>
        /// <returns></returns>
        public DataTable getAllHD()
        {
            // Tạo dataTable
            DataTable dt = new DataTable();

            // Thực thi sql
            try
            {
                // Mở kết nối
                _conn.Open();

                // Đặt tên column
                string column = "mahoadon AS 'Mã Hóa Đơn', makh AS 'Mã KH', chisocu AS 'Chỉ số cũ', chisomoi AS 'Chỉ số mới', sokw AS 'Số KW', tongtien AS 'Tổng Tiền'";

                // query string
                string SQL = "SELECT " + column + " FROM hoadon";

                // Query
                SqlDataAdapter da = new SqlDataAdapter(SQL, _conn);

                // Fill vào dataTable
                da.Fill(dt);

                // Return ở bên dưới
            }
            catch (Exception e)
            {

            }
            finally
            {
                // Đóng kết nối
                _conn.Close();
            }

            return dt;
        }

        /// <summary>
        /// Lấy toàn bộ khách hàng
        /// </summary>
        /// <returns></returns>
        public DataTable getAllKH()
        {
            // Tạo dataTable
            DataTable dt = new DataTable();

            // Thực thi sql
            try
            {
                // Mở kết nối
                _conn.Open();

                // query string
                string SQL = "SELECT * FROM khachhang";

                // Query
                SqlDataAdapter da = new SqlDataAdapter(SQL, _conn);

                // Fill vào dataTable
                da.Fill(dt);

                // Return ở bên dưới
            }
            catch (Exception e)
            {

            }
            finally
            {
                // Đóng kết nối
                _conn.Close();
            }

            return dt;
        }

        /// <summary>
        /// Thêm hóa đơn
        /// </summary>
        /// <param name="mahd"></param>
        /// <param name="makh"></param>
        /// <param name="cu"></param>
        /// <param name="moi"></param>
        /// <param name="kw"></param>
        /// <param name="tien"></param>
        /// <returns></returns>
        public bool themHoaDon(string mahd, string makh, int cu, int moi, int kw, int tien)
        {
            // Thực thi sql
            try
            {
                // Mở kết nối
                _conn.Open();

                // query string
                string SQL = string.Format("INSERT INTO hoadon VALUES (N'{0}', N'{1}', {2}, {3}, {4}, {5})", mahd, makh, cu, moi, kw, tien);

                // Query
                SqlCommand cmd = new SqlCommand(SQL, _conn);

                // Execute và kiểm tra
                if (cmd.ExecuteNonQuery() > 0)
                    return true;
            }
            catch (Exception e)
            {

            }
            finally
            {
                // Đóng kết nối
                _conn.Close();
            }

            return false;
        }

        /// <summary>
        /// Sửa hóa đơn
        /// </summary>
        /// <param name="mahd"></param>
        /// <param name="makh"></param>
        /// <param name="cu"></param>
        /// <param name="moi"></param>
        /// <param name="kw"></param>
        /// <param name="tien"></param>
        /// <returns></returns>
        public bool suaHoaDon(string mahd, string makh, int cu, int moi, int kw, int tien)
        {
            // Thực thi sql
            try
            {
                // Mở kết nối
                _conn.Open();

                // query string
                string SQL = string.Format("UPDATE hoadon SET makh = N'{0}', chisocu = {1}, chisomoi = {2}, sokw = {3}, tongtien = {4} WHERE mahoadon = N'{5}'", makh, cu, moi, kw, tien, mahd);

                // Query
                SqlCommand cmd = new SqlCommand(SQL, _conn);

                // Execute và kiểm tra
                if (cmd.ExecuteNonQuery() > 0)
                    return true;
            }
            catch (Exception e)
            {

            }
            finally
            {
                // Đóng kết nối
                _conn.Close();
            }

            return false;
        }

        /// <summary>
        /// Xóa hóa đơn
        /// </summary>
        /// <param name="mahd"></param>
        /// <returns></returns>
        public bool xoaHoaDon(string mahd)
        {
            // Thực thi sql
            try
            {
                // Mở kết nối
                _conn.Open();

                // query string
                string SQL = string.Format("DELETE FROM hoadon WHERE mahoadon = N'{0}'", mahd);

                // Query
                SqlCommand cmd = new SqlCommand(SQL, _conn);

                // Execute và kiểm tra
                if (cmd.ExecuteNonQuery() > 0)
                    return true;
            }
            catch (Exception e)
            {

            }
            finally
            {
                // Đóng kết nối
                _conn.Close();
            }

            return false;
        }

        /// <summary>
        /// Hàm tìm kiếm
        /// </summary>
        /// <param name="type"></param>
        /// <param name="keyword"></param>
        /// <returns></returns>
        public DataTable timKiem(bool type, string keyword)
        {
            // Tạo dataTable
            DataTable dt = new DataTable();

            // Thực thi sql
            try
            {
                // Mở kết nối
                _conn.Open();
                string SQL, column;

                // Kiểm tra kiểu tìm (true => tìm theo hóa đơn, false tìm theo khách hàng)
                if (type == true)
                {
                    // Đặt tên column
                    column = "mahoadon AS 'Mã Hóa Đơn', makh AS 'Mã KH', chisocu AS 'Chỉ số cũ', chisomoi AS 'Chỉ số mới', sokw AS 'Số KW', tongtien AS 'Tổng Tiền'";

                    // query string
                    SQL = "SELECT " + column + " FROM hoadon WHERE mahoadon LIKE '%" + keyword + "%'";
                }
                else
                {
                    // Đặt tên column
                    column = "makh AS 'Mã Khách Hàng', tenkh AS 'Tên Khách Hàng'";

                    // query string
                    SQL = "SELECT " + column + " FROM khachhang WHERE makh LIKE '%" + keyword + "%'";
                }

                // Query
                SqlDataAdapter da = new SqlDataAdapter(SQL, _conn);

                // Fill vào dataTable
                da.Fill(dt);

                // Return ở bên dưới
            }
            catch (Exception e)
            {

            }
            finally
            {
                // Đóng kết nối
                _conn.Close();
            }

            return dt;
        }
    }
}
