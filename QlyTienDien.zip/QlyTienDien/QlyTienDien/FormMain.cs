﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace QlyTienDien
{
    public partial class FormMain : Form
    {
        public FormMain()
        {
            InitializeComponent();
        }

        private void thoátToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        private void nhậpHóaĐơnToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form_NhapHoaDon hd = new QlyTienDien.Form_NhapHoaDon();

            // Set MDI và show
            hd.MdiParent = this;
            hd.Show();
        }

        private void thôngTinKHHĐToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form_TimKiem tk = new Form_TimKiem();

            // Set MDI
            tk.MdiParent = this;
            tk.Show();
        }

        private void thốngKêHóaĐơnToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormThongKe tk = new FormThongKe();

            // Set MDI
            tk.MdiParent = this;
            tk.Show();
        }
    }
}
