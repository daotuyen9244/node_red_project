﻿CREATE TABLE hoadon (
	mahoadon nvarchar(50) primary key,
	makh nvarchar(50) foreign key (makh) references khachhang(makh),
	chisocu int,
	chisomoi int,
	sokw int,
	tongtien int
)

CREATE TABLE khachhang(
	makh nvarchar(50) primary key,
	tenkh nvarchar(50)
)

INSERT INTO khachhang VALUES 
('KH001', N'Nguyễn Văn A'),
('KH002', N'Đào Thị B'),
('KH003', N'Trần Minh Phát'),
('KH004', N'SethPhat.com')