#ifndef __SD_DISKIO_H
#define __SD_DISKIO_H

/* Includes ------------------------------------------------------------------*/
#include "bsp_driver_sd.h"

/* Exported constants --------------------------------------------------------*/
extern const Diskio_drvTypeDef SD_Driver;

#endif 
